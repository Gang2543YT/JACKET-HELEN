# ShadowPlay AI — Android starter project

A free, local-only Android starter app with:
- Android's explicit MediaProjection consent flow for screen capture.
- A foreground capture service that samples screen luminance (it does not upload screenshots).
- An opt-in AccessibilityService that taps a configured screen point on a repeating interval.
- A neon terminal-style control panel and stop controls.

## Important scope note
This is **not yet a vision-based game-playing AI**. It does not recognize game objects, understand goals, or adapt its actions to what happens on screen. It repeatedly taps one fixed location while screen capture is active. Different games need different strategies; some games prohibit automation. Use only where permitted.

## Build an APK (free)
1. Install Android Studio from https://developer.android.com/studio on a computer.
2. Extract this project ZIP.
3. In Android Studio choose **Open** and select the `ShadowPlayAI` folder.
4. Let Gradle sync. If prompted, install Android SDK Platform 35 and a compatible Android Gradle Plugin.
5. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. When the build finishes, choose **locate**. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfer the APK to your Android phone, open it, and allow installation from that source if Android asks. You may also connect your phone over USB and use Android Studio's Run button.

## First run
1. Open ShadowPlay AI.
2. Tap **GRANT SCREEN CAPTURE** and approve Android's system dialog.
3. Tap **OPEN ACCESSIBILITY SETTINGS** and enable **ShadowPlay AI Game Controls**. This powerful permission is used only to dispatch taps; Android will warn you about it.
4. Return to the app. Set tap coordinates as percentages of the screen (0–100) and an interval of at least 500 ms.
5. Tap **SAVE SETTINGS**, then **START AUTO-PLAY**.
6. Switch to a game where automation is allowed. To stop, return to the app and tap **STOP AUTO-PLAY**. Stop screen capture when finished. You can always revoke the accessibility permission in Android Settings.

## Notes
- Requires Android 8.0 (API 26) or newer; targets SDK 35.
- No API key, cloud service, or paid model is needed for the fixed-tap functionality.
- Android may stop capture if permission is revoked or the service is killed. Re-grant screen capture after restarting it.
- For a real game-specific agent, add on-device image recognition and a strategy tuned to the chosen game. Keep the user's explicit capture and control permissions.
