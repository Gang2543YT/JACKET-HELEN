package com.shadowplay.ai

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.graphics.Color

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("shadowplay", Context.MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var captureStatus: TextView
    private lateinit var autoStatus: TextView
    private lateinit var intervalInput: EditText
    private lateinit var xInput: EditText
    private lateinit var yInput: EditText
    private val projectionRequest = 8102

    private val refresh = object : Runnable {
        override fun run() {
            captureStatus.text = if (prefs.getBoolean("capturing", false)) {
                "● SCREEN FEED ACTIVE  |  avg luminance: ${prefs.getInt("luma", -1).let { if (it < 0) "sampling…" else "$it/255" }}"
            } else "○ SCREEN FEED OFF"
            autoStatus.text = if (prefs.getBoolean("autoplay", false)) "● AUTO-PLAY ARMED" else "○ AUTO-PLAY PAUSED"
            handler.postDelayed(this, 700)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(5, 10, 13)
        window.navigationBarColor = Color.rgb(5, 10, 13)
        setContentView(buildUi())
    }

    override fun onResume() {
        super.onResume()
        handler.post(refresh)
    }

    override fun onPause() {
        handler.removeCallbacks(refresh)
        super.onPause()
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 24)
            setBackgroundColor(Color.rgb(5, 10, 13))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, ViewGroup.LayoutParams(-1, -1))

        content.addView(label("SHADOWPLAY // AI", 28, "#00F5A0"))
        content.addView(label("SCREEN VISION  •  GAME AUTOMATION", 12, "#71A89A"))
        content.addView(label("────────────────────────────────", 14, "#126B52"))
        content.addView(label("SYSTEM STATUS", 15, "#00F5A0"))
        captureStatus = label("○ SCREEN FEED OFF", 13, "#D6E7E1")
        autoStatus = label("○ AUTO-PLAY PAUSED", 13, "#D6E7E1")
        content.addView(captureStatus)
        content.addView(autoStatus)

        content.addView(label("1 / SCREEN ACCESS", 16, "#00F5A0").apply { setPadding(0, 24, 0, 6) })
        content.addView(label("Android will show its own screen-sharing consent dialog.", 12, "#B7C9C3"))
        content.addView(actionButton("GRANT SCREEN CAPTURE") { requestCapture() })
        content.addView(actionButton("STOP SCREEN CAPTURE") {
            stopService(Intent(this, ScreenCaptureService::class.java))
            prefs.edit().putBoolean("capturing", false).apply()
        })

        content.addView(label("2 / AUTHORIZE CONTROLS", 16, "#00F5A0").apply { setPadding(0, 22, 0, 6) })
        content.addView(label("Enable the service below. Android requires this explicit permission.", 12, "#B7C9C3"))
        content.addView(actionButton("OPEN ACCESSIBILITY SETTINGS") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })

        content.addView(label("3 / AUTO-PLAY CONFIG", 16, "#00F5A0").apply { setPadding(0, 22, 0, 6) })
        content.addView(label("Tap location is a percentage of the screen (0–100).", 12, "#B7C9C3"))
        intervalInput = edit("Interval in milliseconds (min 500)", prefs.getLong("interval", 1200L).toString())
        xInput = edit("Horizontal position %", prefs.getInt("x_pct", 50).toString())
        yInput = edit("Vertical position %", prefs.getInt("y_pct", 70).toString())
        content.addView(intervalInput)
        content.addView(xInput)
        content.addView(yInput)
        content.addView(actionButton("SAVE SETTINGS") { saveSettings() })
        content.addView(actionButton("▶ START AUTO-PLAY") {
            saveSettings()
            if (!isControlServiceEnabled()) {
                statusToast("Enable ShadowPlay AI in Accessibility Settings first.")
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } else if (!prefs.getBoolean("capturing", false)) {
                statusToast("Start screen capture first, then start auto-play.")
            } else {
                prefs.edit().putBoolean("autoplay", true).apply()
                statusToast("Auto-play armed. Switch to your game; tap STOP here to pause.")
            }
        })
        content.addView(actionButton("■ STOP AUTO-PLAY") {
            prefs.edit().putBoolean("autoplay", false).apply()
            statusToast("Auto-play paused.")
        })

        content.addView(label("SAFETY / LIMITATIONS", 15, "#00F5A0").apply { setPadding(0, 24, 0, 6) })
        content.addView(label("This starter build captures screen frames and repeatedly taps one chosen point. It does not yet understand game objects or choose context-aware moves. Use only in games where automation is allowed. Keep the STOP control accessible; disable the accessibility service in Android Settings to revoke control permission.", 12, "#B7C9C3"))
        content.addView(label("LOCAL ONLY • NO ACCOUNT • NO PAID AI API", 11, "#4B8C78").apply { setPadding(0, 18, 0, 0) })
        return root
    }

    private fun label(text: String, size: Int, color: String) = TextView(this).apply {
        this.text = text
        textSize = size.toFloat()
        setTextColor(Color.parseColor(color))
        setPadding(0, 4, 0, 4)
    }

    private fun edit(hintText: String, value: String) = EditText(this).apply {
        hint = hintText
        setHintTextColor(Color.rgb(85, 125, 112))
        setTextColor(Color.rgb(225, 245, 237))
        textSize = 14f
        setSingleLine(true)
        setText(value)
        setPadding(14, 10, 14, 10)
        setBackgroundColor(Color.rgb(13, 28, 25))
    }

    private fun actionButton(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text
        setTextColor(Color.rgb(0, 245, 160))
        setBackgroundColor(Color.rgb(14, 40, 33))
        isAllCaps = false
        textSize = 14f
        gravity = Gravity.CENTER
        setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, 7, 0, 4)
        layoutParams = lp
    }

    private fun requestCapture() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), projectionRequest)
    }

    @Deprecated("Deprecated by Android but retained for broad compatibility with the simple starter project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == projectionRequest && resultCode == RESULT_OK && data != null) {
            val intent = Intent(this, ScreenCaptureService::class.java).apply {
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(ScreenCaptureService.EXTRA_DATA, data)
            }
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
            prefs.edit().putBoolean("capturing", true).apply()
            statusToast("Screen capture authorized.")
        } else if (requestCode == projectionRequest) {
            statusToast("Screen capture was not authorized.")
        }
    }

    private fun saveSettings() {
        val interval = intervalInput.text.toString().toLongOrNull()?.coerceAtLeast(500L) ?: 1200L
        val x = xInput.text.toString().toIntOrNull()?.coerceIn(0, 100) ?: 50
        val y = yInput.text.toString().toIntOrNull()?.coerceIn(0, 100) ?: 70
        prefs.edit().putLong("interval", interval).putInt("x_pct", x).putInt("y_pct", y).apply()
        intervalInput.setText(interval.toString()); xInput.setText(x.toString()); yInput.setText(y.toString())
        statusToast("Settings saved.")
    }

    private fun isControlServiceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.split(':').any { it.equals("${packageName}/${GameControlService::class.java.name}", true) }
    }

    private fun statusToast(message: String) = android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_LONG).show()
}
