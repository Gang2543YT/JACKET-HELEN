package com.shadowplay.ai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder

class ScreenCaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "projection_data"
        private const val CHANNEL = "shadowplay_capture"
        private const val NOTIFICATION_ID = 42
    }

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) { stopSelf(); return START_NOT_STICKY }
        if (intent.action == "STOP") { releaseCapture(); stopSelf(); return START_NOT_STICKY }
        createChannel()
        val notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("ShadowPlay AI screen capture")
            .setContentText("Screen capture is active until you stop it.")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(NOTIFICATION_ID, notification)

        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
        val data = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_DATA, Intent::class.java) else @Suppress("DEPRECATION") (intent.getParcelableExtra(EXTRA_DATA) as? Intent)
        if (data == null || resultCode == 0) { stopSelf(); return START_NOT_STICKY }
        try {
            val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = mgr.getMediaProjection(resultCode, data)
            val metrics = resources.displayMetrics
            val width = metrics.widthPixels.coerceAtLeast(1)
            val height = metrics.heightPixels.coerceAtLeast(1)
            reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            reader?.setOnImageAvailableListener({ source ->
                val image = source.acquireLatestImage() ?: return@setOnImageAvailableListener
                try {
                    val plane = image.planes[0]
                    val buffer = plane.buffer
                    var sum = 0L
                    var count = 0
                    val pixelStride = plane.pixelStride
                    val rowStride = plane.rowStride
                    val sampleStep = 16
                    var y = 0
                    while (y < height) {
                        var x = 0
                        while (x < width) {
                            val offset = y * rowStride + x * pixelStride
                            if (offset + 2 < buffer.limit()) {
                                val r = buffer.get(offset).toInt() and 0xff
                                val g = buffer.get(offset + 1).toInt() and 0xff
                                val b = buffer.get(offset + 2).toInt() and 0xff
                                sum += (0.2126 * r + 0.7152 * g + 0.0722 * b).toInt()
                                count++
                            }
                            x += sampleStep
                        }
                        y += sampleStep
                    }
                    if (count > 0) getSharedPreferences("shadowplay", MODE_PRIVATE).edit().putInt("luma", (sum / count).toInt()).apply()
                } catch (_: Exception) { } finally { image.close() }
            }, null)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { releaseCapture(); stopSelf() }
            }, null)
            display = projection?.createVirtualDisplay("ShadowPlayCapture", width, height, metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, null)
            getSharedPreferences("shadowplay", MODE_PRIVATE).edit().putBoolean("capturing", true).apply()
        } catch (_: Exception) {
            getSharedPreferences("shadowplay", MODE_PRIVATE).edit().putBoolean("capturing", false).apply()
            releaseCapture(); stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun releaseCapture() {
        try { display?.release() } catch (_: Exception) { }
        display = null
        try { reader?.setOnImageAvailableListener(null, null); reader?.close() } catch (_: Exception) { }
        reader = null
        try { projection?.stop() } catch (_: Exception) { }
        projection = null
        getSharedPreferences("shadowplay", MODE_PRIVATE).edit().putBoolean("capturing", false).apply()
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else @Suppress("DEPRECATION") stopForeground(true)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "Screen capture", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() { releaseCapture(); super.onDestroy() }
}
