package com.shadowplay.ai

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class GameControlService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var tapInFlight = false
    private val loop = object : Runnable {
        override fun run() {
            val prefs = getSharedPreferences("shadowplay", MODE_PRIVATE)
            if (!prefs.getBoolean("autoplay", false) || !prefs.getBoolean("capturing", false)) {
                handler.postDelayed(this, 350)
                return
            }
            if (!tapInFlight) {
                val metrics = resources.displayMetrics
                val xPct = prefs.getInt("x_pct", 50).coerceIn(0, 100)
                val yPct = prefs.getInt("y_pct", 70).coerceIn(0, 100)
                val x = (metrics.widthPixels * xPct / 100f).coerceIn(1f, (metrics.widthPixels - 2).coerceAtLeast(1).toFloat())
                val y = (metrics.heightPixels * yPct / 100f).coerceIn(1f, (metrics.heightPixels - 2).coerceAtLeast(1).toFloat())
                val path = Path().apply { moveTo(x, y) }
                val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 70)).build()
                tapInFlight = true
                val accepted = dispatchGesture(gesture, object : GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) { tapInFlight = false }
                    override fun onCancelled(gestureDescription: GestureDescription?) { tapInFlight = false }
                }, null)
                if (!accepted) tapInFlight = false
            }
            handler.postDelayed(this, prefs.getLong("interval", 1200L).coerceAtLeast(500L))
        }
    }

    override fun onServiceConnected() { super.onServiceConnected(); handler.removeCallbacks(loop); handler.post(loop) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) { }
    override fun onInterrupt() { getSharedPreferences("shadowplay", MODE_PRIVATE).edit().putBoolean("autoplay", false).apply() }
    override fun onDestroy() { handler.removeCallbacks(loop); super.onDestroy() }
}
